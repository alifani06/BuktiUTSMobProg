package com.example.appnime;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailAnime extends AppCompatActivity {

    public static final String EXTRA_FULLNAME = "extra_fullname";
    public static final String EXTRA_NICKNAME= "extra_nickname";
    public static final String EXTRA_DETAIL= "extra_detail";
    public static final String EXTRA_JENIS= "extra_jenis";
    public static final String EXTRA_USE= "extra_use";
    public static final String EXTRA_IMG= "extra_img";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageView imgAnime;
        TextView tvFullName, tvNickName, tvDetail, tvJenis, tvUse;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.anime_detail);
        imgAnime = findViewById(R.id.tv_anime_photo);
        tvFullName = findViewById(R.id.tv_full_name);
        tvNickName = findViewById(R.id.tv_nick_name);
        tvDetail = findViewById(R.id.tv_detail);
        tvJenis = findViewById(R.id.tv_jenis);
        tvUse = findViewById(R.id.tv_use);

        String full = getIntent().getStringExtra(EXTRA_FULLNAME),
                nick = getIntent().getStringExtra(EXTRA_NICKNAME),
                detail = getIntent().getStringExtra(EXTRA_DETAIL),
                jenis = getIntent().getStringExtra(EXTRA_JENIS),
                use = getIntent().getStringExtra(EXTRA_USE);
        int photo = getIntent().getIntExtra(EXTRA_IMG,0);
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), photo);
        imgAnime.setImageBitmap(bmp);
        tvFullName.setText(full);
        tvNickName.setText(nick);
        tvJenis.setText(jenis);
        tvUse.setText(use);
        tvDetail.setText(detail);
    }

}

