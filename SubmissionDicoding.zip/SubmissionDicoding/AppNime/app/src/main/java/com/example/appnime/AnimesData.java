package com.example.appnime;

import java.util.ArrayList;

public class AnimesData {

    private static String[] animeFullName = {
            "One Piece 1998",
            "Bleach Kurosaki",
            "Naruto Shippuden",
            "Dragon Ball Heroes",
            "Fairy Taill Tartaros",
            "Black Clover",
            "Sokugeki No Souma",
            "Boku no Hero Academia",
            "One Punch Man",
            "Dr.Stone"

    };

    private static String[] animeNickName = {
            "One Piece",
            "Bleach",
            "Naruto ",
            "Dragon Ball",
            "Fairy Taill",
            "Black Clover",
            "Sokugeki No Souma",
            "Boku no Hero",
            "One Punch Man",
            "Dr.Stone"

    };
    private static String[] animeDetail = {
            "Bercerita tetang seorang laki-laki bernama Monkey D. Luffy,yang menentang arti dari gelar bajak laut. Daripada kesan nama besar, kejahatan, kekerasan, dia lebih terlihat seperti bajak laut rendahan yang suka bersenang-senang, alasan Luffy menjadi bajak laut adalah tekadnya untuk berpetualang di lautan yang menyenangkan dan bertemu orang-orang baru dan menarik, serta bersama mencari One Piece. Mengikuti jejak pahlawan masa kecilnya, Luffy dan krunya mengarungi Grand Line, melalui petualangan gila, misteri gelap dan memerangi musuh yang kuat, semua itu dilakukan untuk mendapatkan One Piece.",
            "Kurosaki Ichigo bukan seperti siswa SMA biasanya, dia bisa melihat hanti dan roh, suatu hari ia bertemu dengan Kuchiki Rukia seorang Shinigami yang menyelamatkan ia dan keluarganya dari Hollow dengan mempertaruhkan nyawanya, saat pertarungan kekuatan Shinigami Rukia berpindah pada Ichigo hingga membuar Rukia tak bisa kembali melanjutkan tugasnya sendiri dan bekerja sama dengan Ichigo melindungi Kota.",
            "Tiga belas tahun sebelum cerita ini dimulai, seekor monster rubah ekor sembilan bernama Kyuubi menyerang Konoha, sebuah desa shinobi yang terletak di negara Api. Kekacauan terjadi di desa Konoha dan korban banyak berjatuhan. Akhirnya ada seseorang yang berhasil menyegel Kyuubi itu ke tubuh Naruto, seseorang yang berhasil menyegel siluman rubah ekor itu dikenal sebagai Yondaime Hokage, Hokage ke 4 atau Namikaze Minato yang tidak lain adalah ayah dari Naruto.",
            "Pada bulan Mei 2018, sebuah promosi anime berjudul Dragon Ball Heroes telah diumumkan. Ini akan beradaptasi dari arc Kelangsungan Hidup Alam Semesta dan Planet Prison. Dragon Ball Heroes adalah permainan kartu trading dari Jepang yang berbasis pada franchise Dragon Ball",
            "Berlatar di sebuah dunia fiksi, di mana terdapat Guild penyihir bernama “Fairy Tail”. Guild ini bertempat di kota Magnolia, yang berada di Kerajaan Fiore. Saat ini guild tersebut dipimpin oleh Makarov.",
            "Asta adalah seorang anak muda yang mempunyai mimpi menjadi seorang penyihir terhebat di kerajaan. Akan tetapi dia memiliki satu masalah, dia tidak bisa menggunakan sihir. Namun keberuntungan berpihak kepada dia karena mendapatkan Grimoire lima daun yang sangat langka “Black Clover” yang memberinya kekuatan anti-sihir. Walaupun Asta tidak bisa menggunakan sihir, tapi dia tetap bertekad untuk menjadi Kaisar Sihir.",
            "Anime ini bercerita tentang Yukihara Souma yang bermimpi menjadi koki profesional di restoran ayahnya, Jochirou Yukihara dan berusaha melampaui kemampuan memasak ayahnya.",
            "Boku no Hero Academia Season 4 Sub Indo merupakan lanjutan dari musim ketiga sebelumnya. Setelah All Might kehilangan api terakhir dari One For All dia pun memutuskan untuk pensiun. Dan mau tidak mau Midoriya Izuku lah yang harus melanjutkan tekad One For A ll yang diwariskan All Might. Sementara itu Aliansi Penjahat tak henti-hentinya mengincar pahlawan dan menyerang murid Akademi Yuuei lagi.",
            "Saitama, walau penampilannya tidak meyakinkan, dengan ekspresi datar dan kepala yang botak, namun Ia memiliki kekuatan yang luar biasa!.Saitama adalah seorang superhero yang haus akan lawan kuat, sebab musuh setangguh appun, pada akhirnya akan mati hanya dengan satu pukulannya",
            "Suatu hari, seluruh umat manusia berubah menjadi batu karena kilatan cahaya yang menyilaukan. Setelah beberapa ribu tahun berlalu, anak SMA bernama Taiju terbangun dan dikejutkan dengan perubahan dunia. Namun, dia tidak sendirian. Temannya yang mencintai ilmu pengetahuan, Senku, telah bangkit dan bekerja sendirian selama beberapa bulan. Senku memiliki rencana besar dalam benaknya. Dia ingin memulai peradaban manusia dari nol dengan kekuatan ilmu pengetahuan."



    };
    private static String[] animeJenis = {
            "Action, Adventure, Comedy, Drama, Fantasy, Shounen, Super Power",
            "Action, Comedy, Shounen, Super Power, Supernatural",
            "Action, Comedy, Martial Arts,Shounen, Super Power",
            "Action, Comedy, Fantasy, Martial Arts, Shounen, Super Power",
            "Action, Adventure, Comedy, Fantasy, Magic, Shounen",
            "Action, Comedy, Fantasy, Magic, Shounen",
            "Ecchi, School, Shounen",
            "Action, Comedy, School, Shounen, Super Power",
            "Action, Comedy, Parody, Sci-Fi, Seinen, Super Power, Supernatural",
            "Adventure, Sci-Fi, Shounen"

    };
    private static String[] animeUse = {
            "Toei Animation",
            "Pierrot, TV Tokyo",
            "Pierrot, TV Tokyo",
            "Toei Animation",
            "A-1 Pictures, Satelight",
            "Pierrot",
            "J.C.Staff",
            "Bones",
            "Madhouse",
            "TMS Entertainment"

    };
    private static int[] photo = {
            R.drawable.op,
            R.drawable.bleach,
            R.drawable.naruto,
            R.drawable.dball,
            R.drawable.ft,
            R.drawable.bc,
            R.drawable.sns,
            R.drawable.bnh,
            R.drawable.opm,
            R.drawable.stone

    };

    static ArrayList<AnimeArchitecture> getListData() {
        ArrayList<AnimeArchitecture> list = new ArrayList<>();
        for (int position = 0; position < animeNickName.length; position++) {
            AnimeArchitecture nw = new AnimeArchitecture();
            nw.setFullName(animeFullName[position]);
            nw.setNickName(animeNickName[position]);
            nw.setDetail(animeDetail[position]);
            nw.setJenis(animeJenis[position]);
            nw.setUse(animeUse[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }
}


