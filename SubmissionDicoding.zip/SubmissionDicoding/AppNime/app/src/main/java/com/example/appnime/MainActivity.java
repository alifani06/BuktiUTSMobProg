package com.example.appnime;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvAnime;
    private ArrayList<AnimeArchitecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvAnime = findViewById(R.id.rv_anime);
        rvAnime.setHasFixedSize(true);

        list.addAll(AnimesData.getListData());

        showRecyclerList();
    }

    private void showRecyclerList() {
        rvAnime.setLayoutManager(new LinearLayoutManager(this));
        ListAnime listAnime = new ListAnime(list);
        rvAnime.setAdapter(listAnime);

        listAnime.setOnItemClickCallback(new ListAnime.OnItemClickCallback() {
            @Override
            public void onItemClicked(AnimeArchitecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(AnimeArchitecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailAnime.class);
        detailIntent.putExtra(DetailAnime.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailAnime.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailAnime.EXTRA_NICKNAME, nw.getNickName());
        detailIntent.putExtra(DetailAnime.EXTRA_DETAIL, nw.getDetail());
        detailIntent.putExtra(DetailAnime.EXTRA_JENIS, nw.getJenis());
        detailIntent.putExtra(DetailAnime.EXTRA_USE, nw.getUse());
        startActivity(detailIntent);
    }

}
